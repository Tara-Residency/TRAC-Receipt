package codionics.com.tara_receipt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
