class AdminCredentials {
  final String? email;
  final String? accessToken;
  final String? idToken;

  AdminCredentials(this.email, this.accessToken, {this.idToken});
}