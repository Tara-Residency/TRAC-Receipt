import 'PaymentModel.dart';

class ViewReceiptViewModel {
  PaymentModel pm;
  bool isEmailSent;

  ViewReceiptViewModel(this.pm, this.isEmailSent);
  @override
  String toString(){
    return "ViewReceiptModel(${pm.toString()}, $isEmailSent)";
  }
}