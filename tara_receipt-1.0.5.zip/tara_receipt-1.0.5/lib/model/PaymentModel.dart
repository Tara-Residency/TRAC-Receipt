import 'package:tara_invoice/util/string_extensions.dart';

enum PaymentType { None, MaintenanceCharges, Advance, RentalParking, ClubHouseBooking, TransferFee }

class PaymentModel {
  int srNo;
  PaymentType paymentType;
  DateTime paymentFromDate;
  DateTime paymentToDate;
  var name;
  var email;
  var flat;
  num amount = 0;
  var mode;
  var reference;
  var description;
  var checknumber;
  var bank;
  var branch;

  PaymentModel(this.srNo, this.paymentType, this.paymentFromDate, this.paymentToDate, this.name, this.flat, this.amount,
      {this.email, this.mode, this.reference, this.description, this.checknumber, this.bank, this.branch});

  @override
  String toString() {
    return "PaymentModel($srNo, $paymentType, $paymentFromDate, $paymentToDate, $name, $flat, $amount, $email, $mode, $reference, $description, $checknumber, $bank, $branch)";
  }

  static PaymentModel rowToModel(List<dynamic> rowValues) {
    int srNo = rowValues[0];
    var paymentType = rowValues[1].toString().toPaymentType();
    var fromDate = rowValues[2].toString().stringToDate("dd-MM-yyyy");
    var toDate = rowValues[3].toString().stringToDate("dd-MM-yyyy");
    var pm = PaymentModel(srNo, paymentType, fromDate, toDate, rowValues[4], rowValues[6], rowValues[7],
        email: rowValues[5],
        mode: rowValues[8],
        reference: rowValues[9],
        description: rowValues[10],
        checknumber: rowValues[11],
        bank: rowValues[12],
        branch: rowValues[13]);
    return pm;
  }
}
