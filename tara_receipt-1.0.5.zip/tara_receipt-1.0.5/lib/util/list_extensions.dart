extension ListExtension<T> on List<T> {
  List<T> takeRight(int n) {
    int splitLen = (this.length - n) > 0 ? (this.length - n) : 0;
    return this.sublist(splitLen, this.length);
  }

  List<T> dropRight(int n) {
    int splitLen = (this.length - n) > 0 ? (this.length - n) : 0;
    return this.sublist(0, splitLen);
  }
}
