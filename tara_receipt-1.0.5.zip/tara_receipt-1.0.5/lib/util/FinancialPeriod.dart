class FinancialPeriod {
  final DateTime fromDate;
  final DateTime toDate;

  FinancialPeriod(this.fromDate, this.toDate);

  financialPeriod() {
    var fy1;
    var fy2;

    if (fromDate.month <= 3 && fromDate.day <= 31) {
      fy1 = (fromDate.year - 1) - 2000;
      fy2 = fromDate.year - 2000;
    } else {
      fy1 = fromDate.year - 2000;
      fy2 = (fromDate.year + 1) - 2000;
    }
    // print(fy1.toString());
    return ('FY$fy1$fy2');
  }

  @override
  toString() {
    return financialPeriod();
  }
}
