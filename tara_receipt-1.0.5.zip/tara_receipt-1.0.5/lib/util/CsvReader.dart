import 'dart:io';
import 'dart:convert';
import 'dart:async';
import 'package:csv/csv.dart';

class CsvReader {
  final String fileName;

  CsvReader(this.fileName);

  Future<String> readLines() async {
    var file = File(this.fileName);
    return file.readAsString();
  }

  List<List> convert(String lines) {
    return CsvToListConverter().convert(lines);
  }
}