import 'string_extensions.dart';
import 'package:tuple/tuple.dart';
import 'package:quiver/iterables.dart';
import 'list_extensions.dart';

extension NumExtension on int {
  static var ones = ["Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"];
  static var teens = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
  static var tens = ["Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
  static var units = ["Arab", "Crore", "Lakh", "Thousand", "Hundred"];

  String twoDigitNumToWords() {
    assert(this < 100, "Can only convert two digit number to a string.");

    if (this < 10)
      return ones[this];
    else if (this > 10 && this < 20) {
      var diff = this - 10;
      return teens[diff];
    } else {
      int quotient = this ~/ 10;
      var reminder = this % 10;

      if (reminder == 0)
        return tens[quotient - 1];
      else
        return '${tens[quotient - 1]} ${ones[reminder]}';
    }
  }

  String threeDigitNumToWords() {
    assert(this < 1000, "Can only convert three digit number to a string.");

    int quotient = this ~/ 100;
    var reminder = this % 100;

    if (reminder == 0) {
      return "${ones[quotient]} ${units.last}";
    } else {
      var twoDigitWord = reminder.twoDigitNumToWords();
      if (quotient == 0)
        return "$twoDigitWord";
      else
        return "${ones[quotient]} ${units.last} $twoDigitWord";
    }
  }

  numToWords() {
    if (this < 100)
      return this.twoDigitNumToWords();
    else if (this < 1000)
      return this.threeDigitNumToWords();
    else {
      var numStr = this.toString();

      // 12345678 => 1,23,45,678
      Tuple2<String, String> rhTuple = numStr.splitFromRight(3);
      var grouped = rhTuple.item1.groupedFromRight(2);

      var hun = int.parse(rhTuple.item2);
      var hundredString = hun.threeDigitNumToWords();

      List<String> unitsMoreThanHundred = units.dropRight(1).takeRight(grouped.length);
      // print('umth: $unitsMoreThanHundred');
      var amountWithUnit = zip([grouped, unitsMoreThanHundred]);
      // print('awu: $amountWithUnit');
      var moreThanHundredString = amountWithUnit
          .map((e) {
            var amt = int.parse(e.first);
            if (amt == 0)
              return "";
            else
              return "${amt.twoDigitNumToWords()} ${e.last}";
          })
          .where((element) => element.isNotEmpty)
          .join(" ");
      // print('mths: $moreThanHundredString');

      return "$moreThanHundredString $hundredString";
    }
  }
}
