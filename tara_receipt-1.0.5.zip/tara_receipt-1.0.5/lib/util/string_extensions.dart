import 'package:intl/intl.dart';
import 'package:tuple/tuple.dart';
import 'package:tara_invoice/model/PaymentModel.dart';
import 'package:tara_invoice/util/enum_extensions.dart';

extension StringExtension on String {
  splitFromRight(int n) {
    int splitLen = (this.length - n) > 0 ? (this.length - n) : 0;
    return Tuple2<String, String>(this.substring(0, splitLen), this.substring(splitLen, this.length));
  }

  List<String> groupedFromRight(int n) {
    List<String> grouped = [];
    Tuple2<String, String> remainingLastTuple = this.splitFromRight(n);
    grouped.add(remainingLastTuple.item2);

    var remaining = remainingLastTuple.item1;
    while (remaining.isNotEmpty) {
      Tuple2<String, String> rlTuple = remaining.splitFromRight(n);
      grouped.insert(0, rlTuple.item2);
      remaining = rlTuple.item1;
    }

    return grouped;
  }

  /// This property will be able to convert a string to a PaymentType enum
  /// only if the string value is one of the valid values of this enum.
  PaymentType toPaymentType() {
    print(this);
    return PaymentType.values.firstWhere((e) => e.showName == this);
  }

  DateTime stringToDate(String format) {
    var inputFormat = DateFormat(format);
    return inputFormat.parse(this);
  }
}
