import 'package:tara_invoice/model/PaymentModel.dart';

extension PaymentTypeExtension on PaymentType {
  String get showName {
    switch (this) {
      case PaymentType.None:
        return "None";
      case PaymentType.MaintenanceCharges:
        return "Maintenance Charges";
      case PaymentType.Advance:
        return "Advance";
      case PaymentType.RentalParking:
        return "Rental Parking";
      case PaymentType.ClubHouseBooking:
        return "Club House Booking";
      case PaymentType.TransferFee:
        return "Transfer Fee";
    }
  }

  String get abbreviatedName {
    switch (this) {
      case PaymentType.None:
        return "NA";
      case PaymentType.MaintenanceCharges:
        return "MC";
      case PaymentType.Advance:
        return "ADV";
      case PaymentType.RentalParking:
        return "RP";
      case PaymentType.ClubHouseBooking:
        return "CB";
      case PaymentType.TransferFee:
        return "TF";
    }
  }
}
