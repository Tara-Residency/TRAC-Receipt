import '../views/CreateReceiptPage.dart';
import '../views/HomePage.dart';

class PageRoutes {
  static String createReceiptPage = CreateReceiptPage.routeName;
  static String homePage = HomePage.routeName;
}
