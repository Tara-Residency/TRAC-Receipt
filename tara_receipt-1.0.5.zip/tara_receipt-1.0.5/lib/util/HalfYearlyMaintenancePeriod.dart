import 'date_apis.dart';

class HalfYearlyMaintenancePeriod {
  final DateTime fromDate;
  final DateTime toDate;

  HalfYearlyMaintenancePeriod(this.fromDate, this.toDate);

  @override
  toString() {
    String fromDateStr = fromDate.dateToString('dd-MMM-yyyy');
    String toDateStr = toDate.dateToString('dd-MMM-yyyy');

    return ('$fromDateStr to $toDateStr');
  }

  static AprToSep(int year) {
    DateTime fromDate = DateTime.utc(year, 04, 01);
    DateTime toDate = DateTime.utc(year, 09, 30);
    return HalfYearlyMaintenancePeriod(fromDate, toDate);
  }

  static OctToMar(int year) {
    DateTime fromDate = DateTime.utc(year, 10, 01);
    DateTime toDate = DateTime.utc(year + 1, 03, 31);
    return HalfYearlyMaintenancePeriod(fromDate, toDate);
  }

  static List<HalfYearlyMaintenancePeriod> getTenYearsMaintenancePeriods() {
    List<int> years = List.generate(10, (int index) => index + DateTime.now().year);
    return years.map((e) => HalfYearlyMaintenancePeriod.get2PeriodsForAYear(e)).expand((i) => i).toList();
  }

  static List<HalfYearlyMaintenancePeriod> get2PeriodsForAYear(int year) {
    return <HalfYearlyMaintenancePeriod>[HalfYearlyMaintenancePeriod.AprToSep(year), HalfYearlyMaintenancePeriod.OctToMar(year)];
  }

  // [HalfYearlyMaintenancePeriod("1-apr-2021", "30-sep-2021"), HalfYearlyMaintenancePeriod(), HalfYearlyMaintenancePeriod()]

}
