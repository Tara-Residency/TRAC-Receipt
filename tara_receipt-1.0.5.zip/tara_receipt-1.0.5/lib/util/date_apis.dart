import 'package:intl/intl.dart';

extension DateFormatting on DateTime {
  String dateToString(String format) {
    final DateFormat formatter = DateFormat(format);
    return formatter.format(this);
  }
}
