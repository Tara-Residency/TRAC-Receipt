import 'package:flutter/foundation.dart' as kIsWeb;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tara_invoice/model/AdminCredentials.dart';
import 'package:tara_invoice/views/Login.dart';
import 'package:tara_invoice/views/viewReceipt.dart';
import '../model/PaymentModel.dart';
import '../views/CreateReceiptPage.dart';
import 'package:file_picker/file_picker.dart';
import 'package:csv/csv.dart';
import 'dart:convert';

class HomePage extends StatelessWidget {
  static String routeName = "/HomePage";

  const HomePage({Key? key, required this.title, required this.adminCredentials}) : super(key: key);
  final String title;
  final AdminCredentials? adminCredentials;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        //title: Text(title),
        title: RichText(text: TextSpan(text: title, style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold))),
        leading: Icon(Icons.star, size: 50, color: Colors.blueAccent),
        actions: [
          IconButton(
              onPressed: () async {
                final _auth = FirebaseAuth.instance;
                final _user = _auth.currentUser;
                if (_user == null) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text("No one has signed in"),
                  ));
                  Navigator.pushAndRemoveUntil(context,
                      MaterialPageRoute(builder: (context) => Login(title: 'Tara Receipt Generation Tool')), (route) => false);
                }
                (kIsWeb.kIsWeb == true) ? await _auth.signOut() : await _auth.signOut();
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text("${_user!.displayName} has signed out"),
                ));
                Navigator.pushAndRemoveUntil(context,
                    MaterialPageRoute(builder: (context) => Login(title: 'Tara Receipt Generation Tool')), (route) => false);
              },
              icon: Icon(Icons.logout))
        ],
      ),
      body: Center(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              child: Text("CREATE SINGLE RECEIPT"),
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            CreateReceiptPage(title: 'Create Receipt', adminCredentials: adminCredentials)));
                //Navigator.pushNamed(context, CreateReceiptPage.routeName);
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              child: Text('CREATE BULK RECEIPTS'),
              onPressed: () async {
                List<PaymentModel> pmList = [];
                FilePickerResult? picked =
                    await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['csv'], withData: true);

                if (picked != null) {
                  ScaffoldMessenger.of(context)
                      .showSnackBar(SnackBar(content: Text('File uploaded: ${picked.files.first.name}')));
                  var x = picked.files.first.bytes;
                  debugPrint('Byte Data: $x');
                  String lines = Utf8Decoder().convert(x!);
                  debugPrint('Line Data: $lines');

                  try {
                    List<List> rowsAsListOfValues = const CsvToListConverter().convert(lines);
                    //debugPrint('Row 1 Data: ${rowsAsListOfValues[71]}');
                    pmList = rowsAsListOfValues.skip(1).map((e) => PaymentModel.rowToModel(e)).toList();
                    debugPrint('Row 1: ${pmList[0].toString()}');
                  } catch (e) {
                    print('Error 1: $e');
                    ScaffoldMessenger.of(context)
                        .showSnackBar(SnackBar(content: Text('File template incorrect: $e', style: TextStyle(color: Colors.red))));
                  }

                  if (pmList.isNotEmpty) {
                    //debugPrint(pmList.toString());
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                ViewReceipt(title: 'Receipts', adminCredentials: adminCredentials, pmList: pmList)));
                  }
                }
              },
            ),
          ),
        ]),
      ),
    );
  }
}
