import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tara_invoice/model/AdminCredentials.dart';
import '../model/PaymentModel.dart';
import 'viewReceipt.dart';

class PaymentPage extends StatefulWidget {
  PaymentPage(
      {Key? key,
      required this.title,
      required this.paymentType,
      required this.paymentFromDate,
      required this.paymentToDate,
      required this.adminCredentials})
      : super(key: key);

  final String title;
  final paymentType;
  final DateTime paymentFromDate;
  final DateTime paymentToDate;
  final AdminCredentials? adminCredentials;

  @override
  _PaymentPageState createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  var pm = PaymentModel(001, PaymentType.None, DateTime.now(), DateTime.now(), '', '', 0);

  final _formKey = GlobalKey<FormState>();

  var cycleTextController = TextEditingController();
  var receiptNumController = TextEditingController();
  var nameTextController = TextEditingController();
  var emailTextController = TextEditingController();
  var flatTextController = TextEditingController();
  var amountNumController = TextEditingController();
  var refTextController = TextEditingController();
  var descTextController = TextEditingController();
  var cheNumTextController = TextEditingController();
  var bankNameTextController = TextEditingController();
  var bankBranchTextController = TextEditingController();

  var _modeValue = -1;
  double wdLable = 100;
  double htTextForm = 70;

  @override
  Widget build(BuildContext context) {
    double wdTextForm = MediaQuery.of(context).size.width * 0.6;

    return Scaffold(
      appBar: AppBar(title: Text(widget.title), leading: Icon(Icons.star, size: 50, color: Colors.blueAccent)),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: wdLable,
                        child: Row(
                          children: [
                            Text("*", style: TextStyle(color: Colors.red)),
                            Text("Sr No:"),
                          ],
                        ),
                      ),
                      Container(
                        width: wdTextForm,
                        child: Center(
                          child: TextFormField(
                              textAlignVertical: TextAlignVertical.center,
                              controller: receiptNumController,
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                if (value == null || value.isEmpty) return "Receipt Number is required";
                                return null;
                              },
                              decoration: InputDecoration(border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)))),
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: wdLable,
                        child: Row(
                          children: [
                            Text("*", style: TextStyle(color: Colors.red)),
                            Text("Name:"),
                          ],
                        ),
                      ),
                      Container(
                        width: wdTextForm,
                        child: Center(
                          child: TextFormField(
                              textAlignVertical: TextAlignVertical.center,
                              controller: nameTextController,
                              validator: (value) {
                                if (value == null || value.isEmpty) return "Name is required";
                                return null;
                              },
                              decoration: InputDecoration(border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)))),
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: wdLable,
                        child: Row(
                          children: [
                            Text("*", style: TextStyle(color: Colors.red)),
                            Text("Email:"),
                          ],
                        ),
                      ),
                      Container(
                        width: wdTextForm,
                        child: TextFormField(
                            controller: emailTextController,
                            keyboardType: TextInputType.emailAddress,
                            validator: (value) {
                              if (value == null || value.isEmpty) return "Email is required";
                              return null;
                            },
                            decoration: InputDecoration(border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)))),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: wdLable,
                        child: Row(
                          children: [
                            Text("*", style: TextStyle(color: Colors.red)),
                            Text("Flat:"),
                          ],
                        ),
                      ),
                      Container(
                        width: wdTextForm,
                        child: TextFormField(
                            controller: flatTextController,
                            validator: (value) {
                              if (value == null || value.isEmpty) return "Flat is required";
                              return null;
                            },
                            decoration: InputDecoration(border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)))),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: wdLable,
                        child: Row(
                          children: [
                            Text("*", style: TextStyle(color: Colors.red)),
                            Text("Amount:"),
                          ],
                        ),
                      ),
                      Container(
                        width: wdTextForm,
                        child: TextFormField(
                            controller: amountNumController,
                            keyboardType: TextInputType.number,
                            validator: (value) {
                              if (value == null || value.isEmpty) return "Amount is required";
                              return null;
                            },
                            decoration: InputDecoration(border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)))),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      Column(children: [Text("Mode")]),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Radio(value: 0, groupValue: _modeValue, onChanged: (value) => _selectPaymentMode(value)),
                              Text("Electronic Fund Transfer"),
                            ],
                          ),
                          Row(
                            children: [
                              Radio(value: 1, groupValue: _modeValue, onChanged: (value) => _selectPaymentMode(value)),
                              Text("Cheque"),
                            ],
                          ),
                          Row(
                            children: [
                              Radio(value: 2, groupValue: _modeValue, onChanged: (value) => _selectPaymentMode(value)),
                              Text("Cash"),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                if (_modeValue == 0) _showEFTFields(wdTextForm) else if (_modeValue == 1) _showCheckFields(wdTextForm),
                Center(
                  child: ElevatedButton(
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          if (nameTextController.text == "") {
                            ScaffoldMessenger.of(context)
                                .showSnackBar(SnackBar(content: Text('Please enter name', style: TextStyle(color: Colors.red))));
                          } else if (emailTextController.text == "") {
                            ScaffoldMessenger.of(context)
                                .showSnackBar(SnackBar(content: Text('Please enter email', style: TextStyle(color: Colors.red))));
                          } else if (flatTextController.text == "") {
                            ScaffoldMessenger.of(context)
                                .showSnackBar(SnackBar(content: Text('Please enter flat number', style: TextStyle(color: Colors.red))));
                          } else if (amountNumController.text == "") {
                            ScaffoldMessenger.of(context)
                                .showSnackBar(SnackBar(content: Text('Please enter amount', style: TextStyle(color: Colors.red))));
                          } else {
                            generateReceipt();
                          }
                        }
                      },
                      child: Text("Generate Receipt")),
                )
              ],
            ),
          ),
        ),
      ),

      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }

  _showEFTFields(wdTextForm) {
    pm.mode = "Electronics Fund Transfer";
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(width: wdLable, child: Text("Reference:")),
              Container(
                width: wdTextForm,
                child: TextFormField(
                    controller: refTextController, decoration: InputDecoration(border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)))),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(width: wdLable, child: Text("Description:")),
              Container(
                width: wdTextForm,
                child: TextFormField(
                    controller: descTextController,
                    decoration: InputDecoration(border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)))),
              ),
            ],
          ),
        )
      ],
    );
  }

  _showCheckFields(wdTextForm) {
    pm.mode = "Check";
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(width: wdLable, child: Text("Cheque No.: ")),
              Container(
                width: wdTextForm,
                child: TextFormField(
                    controller: cheNumTextController,
                    decoration: InputDecoration(border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)))),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(width: wdLable, child: Text("Bank Name: ")),
              Container(
                width: wdTextForm,
                child: TextFormField(
                    controller: bankNameTextController,
                    decoration: InputDecoration(border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)))),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(width: wdLable, child: Text("Bank Branch: ")),
              Container(
                width: wdTextForm,
                child: TextFormField(
                    controller: bankBranchTextController,
                    decoration: InputDecoration(border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)))),
              ),
            ],
          ),
        )
      ],
    );
  }

  _selectPaymentMode(value) {
    setState(() {
      _modeValue = value;
      //debugPrint('$_modeValue');
    });
  }

  showExportProgressDialog(double val) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          content: Row(
            children: [
              CircularProgressIndicator(value: val),
              Text("  Export Complete"),
            ],
          ),
        );
      },
    );
  }

  generateReceipt() {
    pm.srNo = int.parse(receiptNumController.text);
    pm.paymentType = widget.paymentType;
    pm.paymentFromDate = widget.paymentFromDate;
    pm.paymentToDate = widget.paymentToDate;
    pm.name = nameTextController.text;
    pm.flat = flatTextController.text;
    pm.amount = num.parse(amountNumController.text);
    pm.mode = _modeValue;
    pm.reference = refTextController.text;
    pm.description = descTextController.text;
    pm.checknumber = cheNumTextController.text;
    pm.bank = bankNameTextController.text;
    pm.branch = bankBranchTextController.text;
    pm.email = emailTextController.text;

    List<PaymentModel> pmList = [pm];

    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => ViewReceipt(title: 'Receipts', adminCredentials: widget.adminCredentials!, pmList: pmList)));
    //showExportProgressDialog(100);

    //debugPrint(pm.toString());
  }
}
