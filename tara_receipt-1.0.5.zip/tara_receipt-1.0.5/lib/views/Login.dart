import 'package:flutter/foundation.dart' as kIsWeb;
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'HomePage.dart';
import '../model/AdminCredentials.dart';

import 'package:package_info_plus/package_info_plus.dart';

class Login extends StatefulWidget {
  const Login({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  static final auth = FirebaseAuth.instance;
  var _adminCredentials;
  var version;
  final googleSignIn = GoogleSignIn();
  var adminAccessToken;
  AdminCredentials? adminCredentials;

  String? name;
  String? imageUrl;
  User? user;
  String? adminEmail;

  webSignInWithGoogle() async {
    GoogleAuthProvider authProvider = GoogleAuthProvider();
    authProvider.addScope("https://www.googleapis.com/auth/gmail.send");
    authProvider.addScope("https://mail.google.com/mail");

    try {
      final UserCredential userCredential = await auth.signInWithPopup(authProvider); 
      var header = userCredential.credential!.asMap();
      adminAccessToken = header['accessToken'];
      // debugPrint(header.toString());
      // debugPrint(authProvider.scopes.toString());
      user = userCredential.user;
    } catch (e) {
      print(e);
    }

    if (user != null) {
      setState(() {
        name = user!.displayName;
        imageUrl = user!.photoURL;
        adminEmail = user!.email;
        adminCredentials = AdminCredentials(user!.email, adminAccessToken);

        // debugPrint(name);
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => HomePage(title: 'Tara Receipt Generation Tool', adminCredentials: adminCredentials)));
      });
    } else {
      setState(() {
        //debugPrint(name);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Login Unsuccessful', style: TextStyle(color: Colors.red))));
      });
    }
  }

  mobileFirebaseSignInWithGoogle() async {
    var googleSignInAccount = await GoogleAuthApi.signIn();
    if (googleSignInAccount != null) {
      final userAuth = await googleSignInAccount.authentication;
      final credential = GoogleAuthProvider.credential(accessToken: userAuth.accessToken, idToken: userAuth.idToken);

      try {
        final userCredential = await auth.signInWithCredential(credential);
        var user = userCredential.user;
        if (user != null) {
          _adminCredentials = AdminCredentials(userCredential.user!.email, userAuth.accessToken);
          debugPrint(userCredential.user!.email);
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('${userCredential.user!.displayName} has signed in.', style: TextStyle(color: Colors.white))));
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => HomePage(title: 'Tara Receipt Generation Tool', adminCredentials: _adminCredentials)));
        }
      } on FirebaseAuthException catch (e) {
        debugPrint("In Exception");
        if (e.code == 'account-exists-with-different-credential') {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('The account already exists with a different credential.', style: TextStyle(color: Colors.red))));
        } else if (e.code == 'invalid-credential') {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('Error occurred while accessing credentials. Try again.', style: TextStyle(color: Colors.red))));
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error occurred using Google Sign-In. Try again.', style: TextStyle(color: Colors.red))));
      }
    }
  }
  getPackageVersion() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();

    setState(() {
      version = packageInfo.version;
    });
  }

  @override
  Widget build(BuildContext context) {
    getPackageVersion();
    return Container(
      //color: Colors.deepOrange,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(25.0, 50.0, 25.0, 50.0),
        child: Card(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Column(
                children: [
                  Container(
                    height: 50,
                  ),
                  Text('Tara Residency Receipt Generation Tool', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 20), textAlign: TextAlign.center),
                  Text('Version: $version', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 12), textAlign: TextAlign.center),
                  Container(
                    height: 50,
                  ),
                  InkWell(
                    child: Container(
                      height: MediaQuery.of(context).size.height / 10,
                      width: MediaQuery.of(context).size.width * 2 / 3,
                      decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(20)),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                                height: 50,
                                width: 30,
                                decoration: BoxDecoration(
                                  image: DecorationImage(image: AssetImage('images/google.png'), fit: BoxFit.cover),
                                  shape: BoxShape.circle,
                                )),
                            Text('Sign In with Google',
                                style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold, color: Colors.white)),
                          ],
                        ),
                      ),
                    ),
                    onTap: () => (kIsWeb.kIsWeb == true) ? webSignInWithGoogle() : mobileFirebaseSignInWithGoogle(),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class GoogleAuthApi {

  static final _googleSignIn = GoogleSignIn(scopes: ['https://mail.google.com/',]);

  static signIn() async {
    // if(await _googleSignIn.isSignedIn()) {
    //   return _googleSignIn.currentUser;
    // }else {
    //   return await _googleSignIn.signIn();
    // }
    if(await _googleSignIn.isSignedIn()) {
      await _googleSignIn.signOut();
    }
    return await _googleSignIn.signIn();
  }

  static signOut() async {
    return await _googleSignIn.signOut();
  }

}