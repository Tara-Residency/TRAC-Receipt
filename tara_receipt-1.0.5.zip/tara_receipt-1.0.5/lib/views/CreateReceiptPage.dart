import 'package:flutter/material.dart';
import 'package:tara_invoice/model/AdminCredentials.dart';
import 'package:tara_invoice/model/PaymentModel.dart';

import 'PaymentPage.dart';
import '../util/date_apis.dart';

import '../util/HalfYearlyMaintenancePeriod.dart';

class CreateReceiptPage extends StatefulWidget {
  CreateReceiptPage({Key? key, required this.title, required this.adminCredentials}) : super(key: key);

  static String routeName = "/CreateReceiptPage";

  final String title;
  final AdminCredentials? adminCredentials;

  @override
  _CreateReceiptPageState createState() => _CreateReceiptPageState();
}

class _CreateReceiptPageState extends State<CreateReceiptPage> {
  final _formKey = GlobalKey<FormState>();
  var _paymentTypeValue = PaymentType.None;
  var pm = PaymentModel(001, PaymentType.None, DateTime.now(), DateTime.now(), '', '', 0);
  var fromDate = ' ';
  var toDate = ' ';
  var _periodValue = -1;

  List<HalfYearlyMaintenancePeriod> _periodList = HalfYearlyMaintenancePeriod.getTenYearsMaintenancePeriods();

  _selectPaymentType(var value) {
    setState(() {
      _paymentTypeValue = value;
    });
  }

  _selectPeriodValue(var value) {
    setState(() {
      _periodValue = value;
    });
  }

  setFromDate() async {
    var d = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2021,4,1),
        lastDate: DateTime(DateTime.now().year + 10));
    //debugPrint('$d');
    setState(() {
      if (d != null) {
        pm.paymentFromDate = d;
        // fromDate = '${pm.paymentFromDate.day}' + '-' + '${pm.paymentFromDate.month}' + '-' + '${pm.paymentFromDate.year}';
        fromDate = pm.paymentFromDate.dateToString('dd-MMM-yyyy');
      }
    });
  }

  setToDate() async {
    var d = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2021,4,1),
        lastDate: DateTime(DateTime.now().year + 10));
    //debugPrint('$d');
    setState(() {
      if (d != null) {
        pm.paymentToDate = d;
        toDate = pm.paymentToDate.dateToString('dd-MMM-yyyy');
      }
    });
  }

  _showDateFields() {
    fromDate = pm.paymentFromDate.dateToString('dd-MMM-yyyy');
    toDate = pm.paymentToDate.dateToString('dd-MMM-yyyy');
    return Column(
      children: [
        Row(children: [
          IconButton(icon: Icon(Icons.calendar_today, color: Colors.pink), onPressed: () => setFromDate()),
          Text("From Date: "),
          Text(
            fromDate,
          ),
        ]),
        Row(
          children: [
            IconButton(icon: Icon(Icons.calendar_today, color: Colors.green), onPressed: () => setToDate()),
            Text("To Date: "),
            Text(
              toDate,
            ),
          ],
        )
      ],
    );
  }

  _showPeriodField() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        width: 250,
        child: DropdownButtonFormField(
          validator: (value) {
            if (value == null) return "Cycle is required";
            return null;
          },
          decoration: InputDecoration(border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0))),
          items: _periodList.map<DropdownMenuItem<HalfYearlyMaintenancePeriod>>((HalfYearlyMaintenancePeriod value) {
            return DropdownMenuItem<HalfYearlyMaintenancePeriod>(
                value: value,
                child: Text(
                  value.toString(),
                  style: TextStyle(fontSize: 12),
                ));
          }).toList(),
          onChanged: (value) => _setPaymentPeriod(value),
        ),
      ),
    );
  }

  _setPaymentPeriod(value) {
    setState(() {
      pm.paymentFromDate = value.fromDate;
      //debugPrint('${pm.paymentFromDate}');
      pm.paymentToDate = value.toDate;
      //debugPrint('${pm.paymentToDate}');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title), leading: Icon(Icons.star, size: 50, color: Colors.blueAccent)),
      body: SingleChildScrollView(
          child: Form(
        key: _formKey,
        child:
            Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.start, children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              color: Colors.grey.shade200,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child:
                        Center(child: Text("CHOOSE RECEIPT TYPE", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
                  ),
                  Row(
                    children: [
                      Radio(
                          value: PaymentType.MaintenanceCharges,
                          groupValue: _paymentTypeValue,
                          onChanged: (value) => _selectPaymentType(value)),
                      Text("Maintenance Charges"),
                    ],
                  ),
                  Row(
                    children: [
                      Radio(
                          value: PaymentType.Advance,
                          groupValue: _paymentTypeValue,
                          onChanged: (value) => _selectPaymentType(value)),
                      Text("Advance"),
                    ],
                  ),
                  Row(
                    children: [
                      Radio(
                          value: PaymentType.RentalParking,
                          groupValue: _paymentTypeValue,
                          onChanged: (value) => _selectPaymentType(value)),
                      Text("Rental Parking"),
                    ],
                  ),
                  Row(
                    children: [
                      Radio(
                          value: PaymentType.ClubHouseBooking,
                          groupValue: _paymentTypeValue,
                          onChanged: (value) => _selectPaymentType(value)),
                      Text("Club house Booking"),
                    ],
                  ),
                  Row(
                    children: [
                      Radio(
                          value: PaymentType.TransferFee,
                          groupValue: _paymentTypeValue,
                          onChanged: (value) => _selectPaymentType(value)),
                      Text("Transfer Fee"),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8.0, bottom: 16.0, left: 8.0, right: 8.0),
            child: Card(
              color: Colors.grey.shade200,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child:
                        Center(child: Text("CHOOSE PAYMENT PERIOD", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
                  ),
                  Row(
                    children: [
                      Radio(value: 0, groupValue: _periodValue, onChanged: (value) => _selectPeriodValue(value)),
                      Text('Period'),
                    ],
                  ),
                  if (_periodValue == 0) _showDateFields(),
                  Row(
                    children: [
                      Radio(value: 1, groupValue: _periodValue, onChanged: (value) => _selectPeriodValue(value)),
                      Text('Cycle  '),
                    ],
                  ),
                  if (_periodValue == 1) _showPeriodField(),
                ],
              ),
            ),
          ),
          Center(
              child: ElevatedButton(
                  child: Text("Next"),
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      if (_paymentTypeValue == PaymentType.None) {
                        ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Please choose receipt type', style: TextStyle(color: Colors.red))));
                      } else if (_periodValue > 1 || _periodValue == -1) {
                        ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Please choose payment period', style: TextStyle(color: Colors.red))));
                      } else if (pm.paymentFromDate.isAfter(pm.paymentToDate)) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content: Text('Please choose from date less than to date', style: TextStyle(color: Colors.red))));
                      } else {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => PaymentPage(
                                    title: 'Create Receipt',
                                    paymentType: _paymentTypeValue,
                                    paymentFromDate: pm.paymentFromDate,
                                    paymentToDate: pm.paymentToDate,
                                    adminCredentials: widget.adminCredentials)));
                      }
                    }
                  }))
        ]),
      )),
    );
  }
}
