import 'dart:convert';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tara_invoice/model/AdminCredentials.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:tara_invoice/model/PaymentModel.dart';

import 'dart:io';
import 'package:universal_html/html.dart' as html; //For Web download
import 'package:flutter/foundation.dart' as kIsWeb;

import '../util/generatePDF.dart';
import 'package:mailer/mailer.dart'; //For Android email

import 'package:mailer/smtp_server/gmail.dart'; //For Android email
import '../model/ViewReceiptViewModel.dart';
import '../util/date_apis.dart';

import 'package:http/http.dart' as http; //For Web email
import '../views/Login.dart';
import '../util/enum_extensions.dart';

class ViewReceipt extends StatefulWidget {
  const ViewReceipt({Key? key, required this.title, required this.adminCredentials, required this.pmList})
      : super(key: key);
  final String title;
  final AdminCredentials? adminCredentials;
  final List<PaymentModel> pmList;

  List<ViewReceiptViewModel> getViewReceiptModel() {
    List<ViewReceiptViewModel> vmList = pmList.map((pm) => ViewReceiptViewModel(pm, false)).toList();
    return vmList;
  }

  @override
  _ViewReceiptState createState() => _ViewReceiptState();
}

class _ViewReceiptState extends State<ViewReceipt> {
  List<ViewReceiptViewModel> vmList = [];

  @override
  initState() {
    vmList = widget.getViewReceiptModel();
  }

  Future<bool> sendMobileEmail(ViewReceiptViewModel vm, File? file) async {
    String? userEmail = widget.adminCredentials!.email;
    String? accessToken = widget.adminCredentials!.accessToken;
    debugPrint('UserEmail: $userEmail');

    final smtpServer = gmailSaslXoauth2(userEmail!, accessToken!);
    final message = Message()
      ..from = Address(userEmail, 'Tara Residency')
      ..recipients = [Address(vm.pm.email)]
      //..recipients.add(Address(vm.pm.email))
      ..subject =
          '${vm.pm.paymentType.showName} Receipt for flat ${vm.pm.flat} (${vm.pm.paymentFromDate.dateToString('dd-MMM-yyyy')} to ${vm.pm.paymentToDate.dateToString('dd-MMM-yyyy')})'
      ..text = ''
      ..html = '<h1>Receipt generated against your flat </h1>\n<p>Dear Sir/Madam,<br/><br/>Thanks for your payment. Please'
          ' find attached the ${vm.pm.paymentType.showName} receipt for the period ${vm.pm.paymentFromDate.dateToString('dd-MMM-yyyy')} to ${vm.pm.paymentToDate.dateToString('dd-MMM-yyyy')} generated against your flat ${vm.pm.flat}.<br/><br/>Thanks and regards<br/>BOM Office-Tara Residency</p>'
      ..attachments = [FileAttachment(file!)..location = Location.inline];
    //debugPrint(message.toString());

    try {
      final sendReport = await send(message, smtpServer, timeout: Duration(seconds: 60));
      print('Message sent: ' + sendReport.toString());
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Email Sent"),
      ));
      return true;
    } on MailerException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Email Not Sent"),
      ));
      print('Message not sent.');
      for (var p in e.problems) {
        print('Problem: ${p.code}: ${p.msg}');
      }
      return false;
    }
  }

  sendWebEmail(PaymentModel pm) async {
    Map<String, String> header = {};
    header['Authorization'] = 'Bearer ${widget.adminCredentials!.accessToken}';
    header['Accept'] = 'application/json';
    header['Content-type'] = 'application/json';

    var from = widget.adminCredentials!.email;
    var to = pm.email;
    var subject =
        '${pm.paymentType.showName} Receipt for flat ${pm.flat} (${pm.paymentFromDate.dateToString('dd-MMM-yyyy')} to '
        '${pm.paymentToDate.dateToString('dd-MMM-yyyy')})';
    var message =
        '<h1>Receipt generated against your flat </h1>\n<p>Dear Sir/Madam,<br/><br/>Thanks for your payment. Please '
        'find attached the ${pm.paymentType.showName} receipt for the period ${pm.paymentFromDate.dateToString('dd-MMM-yyyy')} to ${pm.paymentToDate.dateToString('dd-MMM-yyyy')} generated against your flat ${pm.flat}.<br/><br/>Thanks and regards<br/>BOM Office-Tara Residency</p>';
    var pdfbytes = await generatePDF(pm, widget.adminCredentials!.email);
    final base64PDFStr = base64Encode(pdfbytes);

    var filename = "${pm.flat}.pdf";
    var content = '''
From: ${from}
To: ${to}
Subject: ${subject}
MIME-Version: 1.0
Content-Type: multipart/related; boundary="part"; type=Text/HTML
Content-Transfer-Encoding: 7bit

--part
Content-Type: text/html; charset="us-ascii";
$message

--part
Content-ID: <001@abc.com>
Content-Type: APPLICATION/PDF; Content-Disposition="attachment"; name=$filename;
Content-Transfer-Encoding: base64
$base64PDFStr
--part--
''';

    var contentTry = '''
From: ${from}
To: ${to}
Subject: ${subject}
MIME-Version: 1.0
Content-Type: multipart/related; boundary="part"; type=Text/HTML
Content-Transfer-Encoding: 7bit

--part
Content-Type: text/html; charset="us-ascii";
$message

--part
Content-ID: <001@abc.com>
Content-Type: APPLICATION/PDF; Content-Disposition="attachment"; name=$filename;
Content-Transfer-Encoding: base64
$base64PDFStr
--part
Content-ID: <002@abc.com>
Content-Type: APPLICATION/PDF; Content-Disposition="attachment"; name=$filename;
Content-Transfer-Encoding: base64
$base64PDFStr
--part--
''';
    var bytes = utf8.encode(content);
    var base64 = base64Encode(bytes);

    var body = json.encode({'raw': base64});
    //var x = Utf8Decoder().convert(bytes);
    //debugPrint('Content of Message $x');
    debugPrint('Content of Content $base64');

    String apiUrl = 'https://www.googleapis.com/gmail/v1/users/' + from! + '/messages/send?uploadType=multipart';
    Uri uri = Uri.parse(apiUrl);
    final http.Response response = await http.post(uri, headers: header, body: body);
    debugPrint('Response send');
    print(json.decode(response.body));
    if (response.statusCode != 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      print('error: ' + response.statusCode.toString());
      print(data);
      return false;
    } else {
      print('ok: ' + response.statusCode.toString());
      print('ok: ' + response.headers.toString());
      return true;
    }
  }

  showEmailProgressDialog() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: new Row(
            children: [
              CircularProgressIndicator(),
              Container(margin: EdgeInsets.only(left: 10), child: Text(" Sending email..")),
            ],
          ),
        );
      },
    );
  }

  writeAndroidFile(PaymentModel pm) async {
    var documentDirectory = await getApplicationDocumentsDirectory();
    String path = documentDirectory.path;
    var file = File('$path/${pm.flat}.pdf');
    print(file.path);
    file.writeAsBytes(await generatePDF(pm, widget.adminCredentials!.email));
    return file;
  }

  downloadWebFile(PaymentModel pm) async {
    var bytes = await generatePDF(pm, widget.adminCredentials!.email);
    var x = bytes.length;
    final base64Str = base64Encode(bytes);
    var url = "data:application/octet-stream;base64,$base64Str";
    // launch(url);
    html.AnchorElement anchor = html.document.createElement('a') as html.AnchorElement
      ..href = url
      ..style.display = 'none'
      ..download = '${pm.flat}.pdf';

    html.document.body?.children.add(anchor);
    anchor.click();
    html.document.body?.children.remove(anchor);
    html.Url.revokeObjectUrl(url);
  }

  @override
  Widget build(BuildContext context) {
    //debugPrint("Initializing");
    return Scaffold(
      appBar: AppBar(
        title: Text("Receipts"),
        leading: Icon(Icons.star, size: 50, color: Colors.blueAccent),
        actions: [
          IconButton(
              onPressed: () async {
                debugPrint("In Signout");
                final _auth = FirebaseAuth.instance;
                final _user = _auth.currentUser;
                debugPrint(_user.toString());
                if (_user == null) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text("No one has signed in"),
                  ));
                  Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => Login(title: 'Tara Receipt Generation Tool')),
                      (route) => false);
                }
                (kIsWeb.kIsWeb == true) ? await _auth.signOut() : await _auth.signOut();
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text("${_user!.displayName} has signed out"),
                ));
                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => Login(title: 'Tara Receipt Generation Tool')),
                    (route) => false);
              },
              icon: Icon(Icons.logout))
        ],
      ),
      body: ListView.builder(
        shrinkWrap: true,
        itemCount: vmList.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text('Flat: ${vmList[index].pm.flat.toString()}, Amount: ${vmList[index].pm.amount.toString()}'),
            subtitle: Text('Name: ${vmList[index].pm.name}<${vmList[index].pm.email}>'),
            trailing: Container(
              width: 100,
              child: Row(
                children: [
                  IconButton(
                      icon: Icon(
                        Icons.email,
                        color: vmList[index].isEmailSent == true ? Colors.green : Colors.grey,
                      ),
                      onPressed: () async {
                        showEmailProgressDialog();
                        if (kIsWeb.kIsWeb) {
                          bool x = await sendWebEmail(vmList[index].pm);
                          setState(() {
                            vmList[index].isEmailSent = x;
                            Navigator.pop(context);
                          });
                        } else {
                          File mobilePdfFile = await writeAndroidFile(vmList[index].pm);
                          bool x = await sendMobileEmail(vmList[index], mobilePdfFile);
                          setState(() {
                            vmList[index].isEmailSent = x;
                            Navigator.pop(context);
                          });
                        }
                      }),
                  IconButton(
                      icon: Icon(Icons.download_rounded),
                      onPressed: () async {
                        if (kIsWeb.kIsWeb) {
                          downloadWebFile(vmList[index].pm);
                        } else {
                          File mobilePdfFile = await writeAndroidFile(vmList[index].pm);
                          OpenFile.open(mobilePdfFile.path);
                        }
                      }),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
