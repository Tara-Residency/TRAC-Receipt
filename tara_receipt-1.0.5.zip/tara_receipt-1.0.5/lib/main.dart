import 'package:flutter/foundation.dart' as kIsWeb;
import 'package:flutter/material.dart';
import '../views/Login.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if(kIsWeb.kIsWeb == true) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAe7QHkvpLQOuC3H40FuQPZzUUxvXXfgwY",
            authDomain: "tarareceipt.firebaseapp.com",
            projectId: "tarareceipt",
            storageBucket: "tarareceipt.appspot.com",
            messagingSenderId: "982736977832",
            appId: "1:982736977832:web:c1192ec682f2d054a0a79d"));
  }
  else
    await Firebase.initializeApp();
  runApp(TaraInvoice());
}

class TaraInvoice extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tara Receipt Generation Tool',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
      ),
      home: Login(title: 'Tara Receipt Generation Tool'),
    );
  }
}
