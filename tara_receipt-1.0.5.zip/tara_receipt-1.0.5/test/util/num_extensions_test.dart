import 'package:flutter_test/flutter_test.dart';
import 'package:tara_invoice/util/num_extensions.dart';

void main() {
  group('convert two digit amounts into words', () {
    test('should convert 5 into words', () {
      const amt = 5;
      var words = amt.twoDigitNumToWords();
      expect(words, "Five");
    });

    test('should convert 10 into words', () {
      const amt = 10;
      var words = amt.twoDigitNumToWords();
      expect(words, "Ten");
    });

    test('should convert 19 into words', () {
      const amt = 19;
      var words = amt.twoDigitNumToWords();
      expect(words, "Nineteen");
    });

    test('should convert 60 into words', () {
      const amt = 60;
      var words = amt.twoDigitNumToWords();
      expect(words, "Sixty");
    });

    test('should convert 99 into words', () {
      const amt = 99;
      var words = amt.twoDigitNumToWords();
      expect(words, "Ninety Nine");
    });
  });

  group('convert three digit amounts into words', () {
    test('should convert 100 into words', () {
      const amt = 100;
      var words = amt.threeDigitNumToWords();
      expect(words, "One Hundred");
    });

    test('should convert 205 into words', () {
      const amt = 205;
      var words = amt.threeDigitNumToWords();
      expect(words, "Two Hundred Five");
    });

    test('should convert 519 into words', () {
      const amt = 519;
      var words = amt.threeDigitNumToWords();
      expect(words, "Five Hundred Nineteen");
    });

    test('should convert 860 into words', () {
      const amt = 860;
      var words = amt.threeDigitNumToWords();
      expect(words, "Eight Hundred Sixty");
    });

    test('should convert 999 into words', () {
      const amt = 999;
      var words = amt.threeDigitNumToWords();
      expect(words, "Nine Hundred Ninety Nine");
    });
  });

  group('convert higher amounts into words', () {
    test('should convert 800 into words', () {
      const amt = 800;
      var words = amt.numToWords();
      expect(words, "Eight Hundred");
    });

    test('should convert 1001 into words', () {
      const amt = 1001;
      var words = amt.numToWords();
      expect(words, "One Thousand One");
    });

    test('should convert 10010 into words', () {
      const amt = 10010;
      var words = amt.numToWords();
      expect(words, "Ten Thousand Ten");
    });

    test('should convert 100001 into words', () {
      const amt = 100001;
      var words = amt.numToWords();
      expect(words, "One Lakh One");
    });

    test('should convert 1000001 into words', () {
      const amt = 1000001;
      var words = amt.numToWords();
      expect(words, "Ten Lakh One");
    });

    test('should convert 100105 into words', () {
      const amt = 100105;
      var words = amt.numToWords();
      expect(words, "One Lakh One Hundred Five");
    });

    test('should convert 12345 into words', () {
      const amt = 12345;
      var words = amt.numToWords();
      expect(words, "Twelve Thousand Three Hundred Forty Five");
    });

    test('should convert 123456 into words', () {
      const amt = 123456;
      var words = amt.numToWords();
      expect(words, "One Lakh Twenty Three Thousand Four Hundred Fifty Six");
    });

    test('should convert 1234567 into words', () {
      const amt = 1234567;
      var words = amt.numToWords();
      expect(words, "Twelve Lakh Thirty Four Thousand Five Hundred Sixty Seven");
    });

    test('should convert 12345678 into words', () {
      const amt = 12345678;
      var words = amt.numToWords();
      expect(words, "One Crore Twenty Three Lakh Forty Five Thousand Six Hundred Seventy Eight");
    });
  });
}
