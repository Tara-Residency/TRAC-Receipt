import 'package:flutter_test/flutter_test.dart';
import 'package:tara_invoice/util/string_extensions.dart';

void main() {
  group('string extensions test splitFromRight', () {
    const s = "aboli";

    test('should be able to split a string from right, when n is 0', () {
      var tuple = s.splitFromRight(0);
      expect(tuple.item1, "aboli");
      expect(tuple.item2, "");
    });

    test('should be able to split a string from right, when n < length', () {
      var tuple = s.splitFromRight(2);
      expect(tuple.item1, "abo");
      expect(tuple.item2, "li");
    });

    test('should be able to split a string from right, when n > length', () {
      var tuple = s.splitFromRight(6);
      expect(tuple.item1, "");
      expect(tuple.item2, "aboli");
    });
  });

  group('string extensions test groupedFromRight', () {
    test('should be able to group from right an amount of odd length', () {
      const amt = "12345";
      var grouped = amt.groupedFromRight(2);
      expect(grouped[0], "1", reason: "first item did not match");
      expect(grouped[1], "23", reason: "second item did not match");
      expect(grouped[2], "45", reason: "third item did not match");
    });

    test('should be able to group from right an amount of even length', () {
      const amt = "123456";
      var grouped = amt.groupedFromRight(2);
      expect(grouped[0], "12", reason: "first item did not match");
      expect(grouped[1], "34", reason: "second item did not match");
      expect(grouped[2], "56", reason: "third item did not match");
    });
  });
}
