import 'package:flutter_test/flutter_test.dart';
import 'package:tara_invoice/model/PaymentModel.dart';
import 'package:tara_invoice/util/enum_extensions.dart';
import 'package:tara_invoice/util/string_extensions.dart';

void main() {
  group('converting a payment type enum to string', () {
    test('should convert a MaintenanceCharges enum value to a string', () {
      var mc = PaymentType.MaintenanceCharges;
      expect(mc.showName, "Maintenance Charges");
    });

    test('should convert a RentalParking enum value to an abbreviated string', () {
      var mc = PaymentType.RentalParking;
      expect(mc.abbreviatedName, "RP");
    });
  });

  group('converting a string to payment type enum', () {
    test('should convert a Rental Parking string value to an enum', () {
      var rp = "Rental Parking";
      var pt = rp.toPaymentType;
      expect(pt, PaymentType.RentalParking);
    });
  });
}
