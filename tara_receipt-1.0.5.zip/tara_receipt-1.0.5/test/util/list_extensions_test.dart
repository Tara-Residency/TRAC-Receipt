import 'package:flutter_test/flutter_test.dart';
import 'package:tara_invoice/util/list_extensions.dart';

void main() {
  group('list extensions test dropRight', () {
    const s = [1, 2, 3, 4, 5];

    test('should be able to drop a list from right', () {
      List S1 = s.dropRight(1);
      List S2 = s.dropRight(6);
      expect(S1, [1, 2, 3, 4]);
      expect(S2, []);
    });
  });

  group('list extensions test takeRight', () {
    const s = [1, 2, 3, 4, 5];

    test('should be able to drop a list from right', () {
      List S1 = s.takeRight(1);
      List S2 = s.takeRight(6);
      expect(S1, [5]);
      expect(S2, [1, 2, 3, 4, 5]);
    });
  });
}
