## Tara Residency Receipt Generation Tool

## Generate payment receipt for Tara Residency

## Release 1.0.0
Issues:
1. Application is using deprecated gmail API. - resolved in 1.0.1
2. The send email is possible only when google account sets Less secure app access: ON - resolved in 1.0.1
3. The web version can not send email. Hence excluded. Also adding attachment to email, not sure how to do it.

## Release 1.0.1
After choosing another PC, below issues observed:
1. Certain google services like Google Sign-In requires SHA-1 signing certificate so that and OAuth2 client and API key is generated for the app. 
Use Google Play Console to get SHA-1 if app is using "Google Play App Signing".

If app is self-signed use following command at the terminal
keytool -list -v \
-alias androiddebugkey -keystore ~/.android/debug.keystore
password: android
SHA1: 91:32:94:24:E8:65:83:5B:45:FE:EA:7C:45:D7:C3:4C:79:AE:40:3E
SHA256: 58:7A:82:BB:17:38:23:B5:CD:1F:13:40:91:1E:17:52:70:29:D7:86:B9:4B:61:FC:4E:1F:95:ED:2C:45:4C:E9
Add these finger prints to Firebase app settings.
Run "Flutter Clean"

Download google-services.json and add to tara_receipt>android>app>google-services.json

2. Removed api usage io.flutter.embedding.android.SplashScreenDrawable in app>main>AndroidManifest.xml

3. Email is not sent. Implementation done as per the video and resolved
   https://www.youtube.com/watch?v=RDwst9icjAY
4. The app remains in "Testing" phase as in production requires other formalities.   

## Release 1.0.2
1. Fix the issue of blank screen after back button is pressed.
2. Fix the issue of signout, added firebase sign out and google sign out. Also added Firebase sign in.

## Release 1.0.3
1. Fix the issue of login screen after sign in button is pressed.

Release 1.0.3A
1. HomePage.dart --> commented debugPrint('Row 1 Data: ${rowsAsListOfValues[71]}'); because it was causing error in file upload.
2. CsvReader.dart added to resolve the issue of CSV file upload error.
Issues:
1. Program is unable to accept the CSV file converted from excel. It is accepting few CSV file, not sure what is the reason.
2. Name as TaraReceiptBulkUploadOct-Mar22.CSV is not acceptable but program is accepting TaraReceiptBulkUploadOct-Mar22-Final.CSV or TaraReceiptBulkUploadOct-Mar22-1.CSV. This is strange issue, not sure what is the reason.

## Release 1.0.4
1. CreateReceiptPage.dart --> firstDate hardcoded to firstDate: DateTime(2021,4,1) because receipts should be able to generate from year 2021.
2. TransferFee and Club House Booking radio buttons added to Payment Types because there is new request to generate receipts for these type of payments.
3. viewReceipt.dart -->  Added below conditions to sendMobileEmail function
   : (vm.pm.paymentType == PaymentType.RentalParking) ? 'Rental Parking'
   : (vm.pm.paymentType == PaymentType.ClubHouseBooking) ? 'Club House Booking'
   : 'Transfer Fee';
4. generatePDF.dart --> added below conditions
   : (pm.paymentType == PaymentType.RentalParking) ? 'Rental Parking'
   : (pm.paymentType == PaymentType.ClubHouseBooking) ? 'Club House Booking'
   : 'Transfer Fee';
5.generatePDF.dart --> added below conditions
   : paymentType == 'Rental Parking' ? 'RP'
   : paymentType == 'Club House Booking' ? 'CB'
   : 'TF';
6. generatePDF.dart --> new file added to calculate financialperiod because id a date of 31-Mar-22 is given, the financial year getting calculated is 2223, which is incorrect.
7. generatePDF.dart -->  var mode = pm.mode == null ? '-' : pm.mode == 2 ? 'Cash': pm.mode; to consider cash option.   
8. PaymentPage.dart --> Below code added to add a 'Cash' field to the receipt.
   Row(
   children: [
   Radio(value: 2, groupValue: _modeValue, onChanged: (value) => _selectPaymentMode(value)),
   Text("Cash"),
   ],
   ),
9. PaymentPage.dart --> pm.mode = _modeValue; added to generateReceipt()
10. Login,dart --> App version added to the login page.

## Release 1.0.5
1. Web feature implemented. Email and file download working.
2. Num_extensions.dart --> return statement was missing to return this.threeDigitNumToWords(); Hence 800 was
   displayed as Null
3. Num_extensions.dart --> assert function added for null safety.
   assert(this < 1000, "Can only convert three digit number to a string.");
   assert(this < 100, "Can only convert two digit number to a string.");
4. HomePage.dart --> Logout functionality added for web (kIsWeb.kIsWeb == true) ? await _auth.signOut() : await _auth.signOut();
5. viewReceipt.dart --> Logout functionality added for web (kIsWeb.kIsWeb == true) ? await _auth.signOut() : await _auth.signOut();
6. pubspec.yaml--> all package versions updated to the latest to avoid deprication warning.
7. generatePDF.dart -->  var mode = pm.mode == null ? '-' : pm.mode == -1 ? '-' :pm.mode == 2 ? 'Cash': pm.mode;
8. For web hosting, gitHub page is used.
9. GoogleSignIn pop up vanishing in a second because website hosted is not added to authenticated in Firebase--> 
   A. Comment the  <!-- <base href="/"> --> otherwise blank page gets displayed.
   B. Get client id from Google Cloud Platform or Firebase.
   C. Add this to head of the index.html as <meta name="google-signin-client_id" 
   content="982736977832-cp4j49bau644tlcbu8c7f2r2nks3eojv.apps.googleusercontent.com
     .apps.googleusercontent.com">
   D. Add firebase script and firrebaseConfig in index.html as below
   <!-- The core Firebase JS SDK is always required and must be listed first -->
   <script src="https://www.gstatic.com/firebasejs/9.6.9/firebase-app.js"></script>
   <script src="https://www.gstatic.com/firebasejs/7.8.0/firebase-auth.js"></script>
   <script type="module">
     // Import the functions you need from the SDKs you need
     import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.9/firebase-app.js";
     // TODO: Add SDKs for Firebase products that you want to use
     // https://firebase.google.com/docs/web/setup#available-libraries
   
     // Your web app's Firebase configuration
     const firebaseConfig = {
       apiKey: "AIzaSyAe7QHkvpLQOuC3H40FuQPZzUUxvXXfgwY",
       authDomain: "tarareceipt.firebaseapp.com",
       projectId: "tarareceipt",
       storageBucket: "tarareceipt.appspot.com",
       messagingSenderId: "982736977832",
       appId: "1:982736977832:web:c1192ec682f2d054a0a79d"
     };
   
     // Initialize Firebase
     const app = initializeApp(firebaseConfig);
   </script>
   E. Add authorized domains aboli-waikar.github.io and tara-residency.github.io to Firebase Console for web app. 
     (Google Cloud Platform is automatically updated) 

